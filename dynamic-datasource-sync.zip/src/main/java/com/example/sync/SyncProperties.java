package com.example.sync;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@ConfigurationProperties(prefix = "app")
@Getter
@Setter
public class SyncProperties {
    private List<String> sources;
    private Map<String, DbConfig> source = new HashMap<>();
    private DbConfig target;
    private String syncCron;

    @Getter
    @Setter
    public static class DbConfig {
        private String url;
        private String username;
        private String password;
        private List<String> tables;
    }
}
