package com.example.sync;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

@Configuration
@RequiredArgsConstructor
public class DataSourceConfig {

    private final SyncProperties props;

    @Bean
    public Map<String, JdbcTemplate> sourceJdbcTemplateMap() {
        Map<String, JdbcTemplate> map = new HashMap<>();
        for (String key : props.getSources()) {
            SyncProperties.DbConfig cfg = props.getSource().get(key);
            DataSource ds = DataSourceBuilder.create()
                    .url(cfg.getUrl())
                    .username(cfg.getUsername())
                    .password(cfg.getPassword())
                    .build();
            map.put(key, new JdbcTemplate(ds));
        }
        return map;
    }

    @Bean
    public JdbcTemplate targetJdbcTemplate() {
        SyncProperties.DbConfig cfg = props.getTarget();
        DataSource ds = DataSourceBuilder.create()
                .url(cfg.getUrl())
                .username(cfg.getUsername())
                .password(cfg.getPassword())
                .build();
        return new JdbcTemplate(ds);
    }
}
