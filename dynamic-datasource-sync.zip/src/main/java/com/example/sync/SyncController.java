package com.example.sync;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/sync")
public class SyncController {

    private final SyncService syncService;
    private final SyncProperties props;

    @PostMapping("/trigger")
    public String triggerSync() {
        for (String sourceKey : props.getSources()) {
            List<String> tables = props.getSource().get(sourceKey).getTables();
            for (String table : tables) {
                try {
                    syncService.syncTable(sourceKey, table);
                } catch (Exception e) {
                    return "Failed syncing " + sourceKey + "." + table + ": " + e.getMessage();
                }
            }
        }
        return "Sync triggered manually.";
    }
}
