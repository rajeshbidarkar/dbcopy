package com.example.sync;

import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class SyncScheduler {

    private final SyncProperties props;
    private final SyncService syncService;

    @Scheduled(cron = "#{@syncProperties.syncCron}")
    public void run() {
        for (String sourceKey : props.getSources()) {
            List<String> tables = props.getSource().get(sourceKey).getTables();
            for (String table : tables) {
                try {
                    syncService.syncTable(sourceKey, table);
                } catch (Exception e) {
                    System.err.println("Error syncing " + sourceKey + "." + table + ": " + e.getMessage());
                }
            }
        }
    }
}
