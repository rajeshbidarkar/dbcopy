package com.example.dbcopy.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class DbCopyService {

    @Value("#{${copy.tables}}")
    private Map<String, String> tableSourceMap;

    private final JdbcTemplate sourceSgJdbc;
    private final JdbcTemplate sourceLnJdbc;
    private final JdbcTemplate targetJdbc;

    public DbCopyService(JdbcTemplate sourceSgJdbc, JdbcTemplate sourceLnJdbc, JdbcTemplate targetJdbc) {
        this.sourceSgJdbc = sourceSgJdbc;
        this.sourceLnJdbc = sourceLnJdbc;
        this.targetJdbc = targetJdbc;
    }

    public Map<String, String> copyAllTables() {
        Map<String, String> stats = new LinkedHashMap<>();

        for (Map.Entry<String, String> entry : tableSourceMap.entrySet()) {
            String table = entry.getKey();
            String source = entry.getValue();
            long start = System.currentTimeMillis();

            try {
                JdbcTemplate sourceJdbc = getSourceJdbc(source);
                List<Map<String, Object>> rows = sourceJdbc.queryForList("SELECT * FROM " + table);

                if (!rows.isEmpty()) {
                    String insertSql = buildInsertSql(table, rows.get(0));
                    Object[][] params = rows.stream()
                        .map(row -> row.values().toArray())
                        .toArray(Object[][]::new);

                    targetJdbc.batchUpdate(insertSql, params);
                }

                stats.put(table, "Copied " + rows.size() + " rows in " + (System.currentTimeMillis() - start) + "ms");
            } catch (Exception e) {
                stats.put(table, "FAILED: " + e.getMessage());
            }
        }

        return stats;
    }

    private JdbcTemplate getSourceJdbc(String source) {
        return switch (source.toLowerCase()) {
            case "sg" -> sourceSgJdbc;
            case "ln" -> sourceLnJdbc;
            default -> throw new IllegalArgumentException("Invalid source: " + source);
        };
    }

    private String buildInsertSql(String tableName, Map<String, Object> row) {
        String columns = String.join(", ", row.keySet());
        String placeholders = row.keySet().stream().map(k -> "?").collect(Collectors.joining(", "));
        return "INSERT INTO " + tableName + " (" + columns + ") VALUES (" + placeholders + ")";
    }
}public Map<String, String> copySingleTable(String table) {
        Map<String, String> stats = new LinkedHashMap<>();
        String source = tableSourceMap.get(table);
        long start = System.currentTimeMillis();

        if (source == null) {
            stats.put(table, "FAILED: No source mapping defined for table.");
            return stats;
        }

        try {
            JdbcTemplate sourceJdbc = getSourceJdbc(source);
            List<Map<String, Object>> rows = sourceJdbc.queryForList("SELECT * FROM " + table);

            if (!rows.isEmpty()) {
                String insertSql = buildInsertSql(table, rows.get(0));
                Object[][] params = rows.stream()
                    .map(row -> row.values().toArray())
                    .toArray(Object[][]::new);

                targetJdbc.batchUpdate(insertSql, params);
            }

            stats.put(table, "Copied " + rows.size() + " rows in " + (System.currentTimeMillis() - start) + "ms");
        } catch (Exception e) {
            stats.put(table, "FAILED: " + e.getMessage());
        }

        return stats;
    }