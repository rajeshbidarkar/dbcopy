package com.example.dbcopy.scheduler;

import com.example.dbcopy.service.DbCopyService;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class DbCopyScheduler {

    private final DbCopyService dbCopyService;

    public DbCopyScheduler(DbCopyService dbCopyService) {
        this.dbCopyService = dbCopyService;
    }

    @Scheduled(cron = "0 0 1 * * *")
    public void runDailyCopy() {
        System.out.println("Starting daily DB copy...");
        Map<String, String> stats = dbCopyService.copyAllTables();
        stats.forEach((table, status) -> System.out.println(table + ": " + status));
    }
}