package com.example.dbcopy.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.*;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;
import org.springframework.boot.jdbc.DataSourceBuilder;

@Configuration
public class SourceSgDataSourceConfig {
    @Bean
    @ConfigurationProperties("spring.datasource.source-sg")
    public DataSource sourceSgDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean
    public JdbcTemplate sourceSgJdbcTemplate(DataSource sourceSgDataSource) {
        return new JdbcTemplate(sourceSgDataSource);
    }
}