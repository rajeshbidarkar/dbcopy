package com.example.sync;

import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor
public class SyncService {

    private final Map<String, JdbcTemplate> sourceJdbcTemplateMap;
    private final JdbcTemplate targetJdbcTemplate;

    public void syncTable(String sourceKey, String tableName) {
        JdbcTemplate sourceJdbc = sourceJdbcTemplateMap.get(sourceKey);
        List<Map<String, Object>> rows = sourceJdbc.queryForList("SELECT * FROM " + tableName);
        if (rows.isEmpty()) return;

        String insertSql = buildInsertSql(tableName, rows.get(0).keySet());
        List<Object[]> args = rows.stream().map(row -> row.values().toArray()).toList();

        targetJdbcTemplate.batchUpdate(insertSql, args);
        System.out.println("Synced " + rows.size() + " rows from [" + sourceKey + "." + tableName + "]");
    }

    private String buildInsertSql(String table, Set<String> columns) {
        String cols = String.join(", ", columns);
        String qs = columns.stream().map(col -> "?").collect(Collectors.joining(", "));
        return "INSERT INTO " + table + " (" + cols + ") VALUES (" + qs + ")";
    }
}
