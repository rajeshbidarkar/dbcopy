package com.example.dbcopy.controller;

import com.example.dbcopy.service.DbCopyService;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.Map;

@RestController
@RequestMapping("/api/copy")
public class DbCopyController {

    private final DbCopyService dbCopyService;

    public DbCopyController(DbCopyService dbCopyService) {
        this.dbCopyService = dbCopyService;
    }

    @PostMapping
    public Map<String, String> triggerAll() {
        return dbCopyService.copyAllTables();
    }

    @PostMapping("/table")
    public Map<String, String> triggerSingleTable(@RequestParam String table) {
        return dbCopyService.copySingleTable(table);
    }
}